// Callbacks
//Callback function: A callback function is a function passed into another function as the argument which is then invoked inside the outer function to complete an action 
function loadScript(src, callback) { //we used callback here to pass function hello or goodmorning in loadscript function and use it there by calling them
  var script = document.createElement("script");
  script.src = src; //src (url) of script

  script.onload = function() {
    console.log("Loaded script with SRC: " + src) //tells script is loaded on console
    callback(null, src); //on load(or when our whatever task is done) it would notify as this and when it would run here goodmorning function will be running
    //null when error is not occured
  }
  //this is called 'callback-based' style of asynchronous programming a function that does something asyncly should provide a callback argument where we put the function to run after it is complete

  script.onerror = function() {
    console.log("Error loading script with SRC: " + src);
    callback(new Error("Src got some error")) //it would show if there is error
  }
  document.body.appendChild(script); //it would run when script won't load when error occurs
}

function hello(error, src) {
  if (error) {
    console.log(error)
    return
  }
  alert('Hello Good Morning!' + src);
}


function goodmorning(error, src) {
  
  if (error) {
    console.log(error) 
    sendEmergencyMessageToCeo(); //when error occurs
    return
  }
  alert('Good morning' + src);
}

loadScript("https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js", goodmorning ) //we added here bootstrap which we had to run also with the function goodmorning that we wanted to execute
//src: "https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"

//Downside of callback:
//here by callback we are giving access of whole function that's been mentioned hence if here loadscript had error then goodmorning's error parameter also become true and then callback will start alert as this whole program is errornous but it's not the case
//callback hell is known as pyramid of doom: when we have callbacks inside callbacks so it becomes difficult to manage (like loop inside loop) which is shown in callback_hell.js