class RailwayForm {
  submit() {
    alert(this.name + ": Your form is submitted for train number: " + this.trainno)
  }
  cancel() {
    alert(this.name + ": This form is cancelled for train number: " + this.trainno)
  }
  fill(givenname, trainno) {
    this.name = givenname
    this.trainno = trainno
  }
}

// Create a form for Harry
let harryForm = new RailwayForm() //Constructor( ) method is called 1st time automatically when we initialize the object if we are using it
// Fill the form with Harry's details
harryForm.fill("Harry", 145316)  //if we used constructor then we don't have to use these function such explicit way

// Create a forms for Rohan
let rohanForm1 = new RailwayForm() //Constructor( ) method is called 2nd time automatically when we initialize the object if we are using it
let rohanForm2 = new RailwayForm() //Constructor( ) method is called 3rd time automatically when we initialize the object if we are using it
// Fill the forms with Rohan's details
rohanForm1.fill("Rohan", 222420)
rohanForm2.fill("Rohan", 2229211)

harryForm.submit()
rohanForm1.submit()
rohanForm2.submit()
rohanForm1.cancel()

//when we create a class in JavaScript we use the constructor And the constructor that is always invoked whenever an object of the class is created