let a = document.getElementsByTagName('div')[0] //div tag's first tag

//a.innerHTML = a.innerHTML + '<h1>Hello World!</h1>'; //replit feature but by this we can print statement inner html of 'a' tag and add hello world statemwnt to it
//Insertion methods-->we 

let div = document.createElement('div'); //create 
div.className="alert" //set class
div.innerHTML = '<h1>Hello World!</h1>' 

document.body.append(div);
//or appendChild(div);

//Insertion methods:
a.append(div); //append at the end of node
a.prepend(div); //insert at beginning of node
a.before(div); //insert before node
a.after(div); //insert after node
a.replaceWith(div); //replace with node

