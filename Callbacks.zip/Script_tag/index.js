console.log("Hello")
let a = 4;
let b = 2;
console.log(a + b)