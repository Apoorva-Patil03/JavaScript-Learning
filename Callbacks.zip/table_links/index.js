let t = document.body.firstElementChild.firstElementChild //first child of first child of body
console.log(t)
console.log(t.rows) //represents all rows(collection of <tr> elements)
console.log(t.caption) //caption of table(reference to <caption>)
console.log(t.tHead) //(reference to <thead>)
console.log(t.tfont) //(reference to <tfont>)
console.log(t.tHead.firstElementChild) //(reference to <thead>'s first child)
// console.log(t.tFoot) 
console.log(t.tBodies) //collection of body elements
console.log(t.rows[1].rowIndex) //collection of <tr> inside

//tr.calls --> collection of td and th
//tr.sectionRowIndex --> index of tr inside enclosing element
//tr.rowIndex --> row number starting from 0
//td.callIndex --> no. of calls inside enclosing <tr>
//typeof object and document are both have 'object'