const changeBgRed = () => {
  document.body.firstElementChild.style.background = "red"
}

let b = document.body
console.log("First child of b is: ", b.firstChild)
console.log("First Element child of b is: ", b.firstElementChild) //to overcome space problem we use this 
//because if we mention this then it won't return node but returns an actual element 
//element only navigation:
//sometimes we don't want text or comment nodes some links only take element nodes into account for example-->
//document.previousElememtSibling -->previous sibling which is an element
//document.nextElememtSibling --> next sibling which is an element
//document.firstElementChild -->first element
//document.lastElementChild -->last element