let a = document.getElementsByClassName("container")[0]
a.onclick = () => {
  let b = document.getElementsByClassName("container")[0]
  b.innerHTML = "Hello World!"
}
//we can use this instead of writing that code in HTML in <div> and <container> tag as by using onclick function events can be handled
//also we have written onclick function on both sides html and JS but JS onclick function ius preferable while running (Maybe by browser)

//an event is a signal that something has happened all the DOM nodes generate such signals
// some important DOM events are:
//Mouse events : click, control menu (right click), mouseover/mouseout ,mousedown/mouseup,mousemove
//keyboard events: keydown and keyup
//form element events:submit ,focus,etc.
//Document events: DOM context loaded

//Handling Events:
//Events can be handled through HTML attributes 
//<input value ='Hey' onclick='alert('hey') type="button"> //we can use any other function like alert here
//elem.onclick=function(){alert("yes")};
//Note: adding a handler with JS executes the existing handler(look after it again as I don't understand now)

