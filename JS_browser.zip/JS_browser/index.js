//alert("Hello") //use console.log here
console.log("Hey harry")