// let x = function(e) {
//   console.log(e.target) //we can get code when we click on that event or element
// console.log(e.,currentTarget) // as we has to know exact which element is handling event exactly as in block may inner elements in block get include so we had to exactly which out of those 
//   console.log(e.type, e.clientX, e.clientY) //coordinates which change when we move cursor so we would know where user actually clicked
//   // alert("Hello World1!")
// }
//we can give any name to event


//if the reference of function is same then we can easily remove handler even handler removing function exist in different function
let x=function(e){
  console.log(e) //where e is event object after running this pointer event is written in console where we can see many properties in list below that
  alert("Hello World1!")  //this event listener will be deleted after if loop is ran
}

let y = function(e) {
  console.log(e)
  alert("Hello World2!")
}

btn.addEventListener('click', x) //here click is when we press btn(button)


btn.addEventListener('click', y)

let a = prompt("What is your favorite number?");


if (a == "2") {
  btn.removeEventListener('click', x) //now we can remove listener which have same reference as 'x' else it won't work until 'reference' isn't same
}

// if (a == "2") {
//   btn.removeEventListener('click', function(e) ){
//   alert("Hello World1!")
//   } //this wont't be working as reference is not here so we would make refernce and pass it to add eventlistener and remove eventlistener
//element.removeEventListener(event,handler) //handler must be same function object for this work




//we can apply many event handlers on any event 
//addEventListener and removeEventListener :
//addEventListener is used to assign multiple handlers to an event
//element.addEventListener(event,handler)
//here actually happens that the browser creates an event object puts delete into it and passes it as an argument to the handler


//elem.oneclick = function(event)({......})
//event.type= event type
//event.currentTarget: which element handled the event
//event clientX/event clientY: coordinates of the cursor
//we can use that JS because when we want to track where user had clicked on website by using this coordinates like clientX and clientY


