first.className = "text-black red"
first.classList //displays class list as in first there are two classes
first.classList.add("red") //it adds class name with value "red"
first.classList.remove("red") //it removes class name with value "red"
first.classList.contains("red") //checks for given class returns true/false
first.classList.toggle("red") //adds class if doesn't exist otherwise removes it for example if we want to show msg on particular condition else not to show
//If we assign something to elem.className it replaces the whole string of classes