let p1 = new Promise((resolve, reject) => {
        setTimeout(() => {
                console.log("Resolved after 2 seconds")
                resolve(56)
        }, 2000)
})

p1.then((value) => {
       console.log(value)
       let p2=new Promise((resolve, reject)=>{ //we here created promise inside of .then
        //return new Promise((resolve, reject)=>{ //or write it otherwise as shown
                setTimeout(() => {resolve("Promise 2") }, 2000)
       })
})
return p2

.then((value) => {
        console.log("We are done") //returned after p2 is done
        return 2 //constant value return don't know what is use
})
 .then((value)=>{ //returned after 2 is done
        console.log("Now we are pakka done")
})

//returning result value like alert(result) to .then to next .then block and it's result to next .then block and so on...
//the idea is to pass the result through the class of .then handlers

//Here is the flow of execuution:
//1. the initial browser resolves in 1 second(assumption)
//2. the next.then() handler is then called which returns a new promise (resolved with 2 value)
//3. the next.then() gets the result of previous one and this keeps on going

//Every call to .then() returns a new promise whose value is passed to the next one and so on we can even create custom promises inside .then()
