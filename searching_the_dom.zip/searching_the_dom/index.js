// Change the card title to red
let ctitle = document.getElementById("firstcardtitle") //create id which obviously unique 
ctitle.style.color = "blue"

// .ABC(class-name) means it is class
// #ABC(id-name) means it is id

//let ctitles = document.querySelectorAll(".card-title")
let ctitles = document.querySelectorAll(".card-title")[0]
ctitles.style.color = "blue" //card's title color change
//ctitles[0].style.color = "blue"
ctitles[1].style.color = "red"
ctitles[2].style.color = "green"
console.log(ctitles)

document.querySelector(".this").style.color = "black"
document.querySelector(".this").style.background = "red"

console.log(document.getElementsByTagName("a"))
console.log(document.querySelector(".card").getElementsByTagName("a")) //here element(one) and elements(many) have diffrence as element returns only one matching element also elements returns many elements
console.log(document.getElementsByName("search"))

//Searching the DOM
//DOM navigation properties are helpful when the elements are to each other if they are not close to each other 
//if they are not close to each other we have some more methods to search the DOM

//document.getElementById --> this method is used to get the element with a given id attribute 
let span =document.getElementsById('span')
span.style.color='red'

//document.querySelectorAll
//returns all element inside an element matching the given CSS selector 

//document.querySelector
//returns all element inside an element matching the given CSS selector 
//a efficient version of elem.querySelectorAll(CSS)[0] //we can also use this but don't ,do it as told

//document.getElementsByTagName
//returns element with the given tag name

//document.getElementsByClassName
//returns element with the given CSS class name(don't forget 's' letter)

//document.getElementsByTagName
//returns element with the given name attribute